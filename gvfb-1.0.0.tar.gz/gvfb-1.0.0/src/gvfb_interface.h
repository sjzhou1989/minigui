#ifndef _GVFB_INTERFACE_H_
#define _GVFB_INTERFACE_H_

#include <glib.h>
#include <gtk/gtk.h>

#include <assert.h>

GtkUIManager *CreateMainMenu (GtkWidget  *window);

#endif /* end of _GVFB_INTERFACE_H_ */

