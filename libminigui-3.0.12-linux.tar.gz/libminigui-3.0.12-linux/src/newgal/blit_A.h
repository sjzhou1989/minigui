/*
**  $Id: blit_A.h 6566 2006-05-10 01:44:57Z xwyan $
**  
**  Copyright (C) 2003 ~ 2006 Feynman Software.
**  Copyright (C) 2001 ~ 2002 Wei Yongming.
**
*/

/* Functions from blitalpha.c */
extern void GAL_BlitAlpha(GAL_BlitInfo *info);

