/*
** $Id: glyph.h 9892 2008-03-20 02:50:02Z xwyan $
**
**glyph.h: Low Level glyph routines.
**
** Copyright (C) 2003 ~ 2007 Feynman Software.
** Copyright (C) 2001 ~ 2002 Wei Yongming.
**
** All right reserved by Feynman Software.
**
** Create date: 2008/02/02
*/

#ifndef GUI_GDI_GLYPH_H
    #define GUI_GDI_GLYPH_H



#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif // GUI_GDI_GLYPH_H


