/*
** $Id: incoreres.h 7337 2007-08-16 03:44:29Z xgwang $
**
** incoreres.h: definitions for incore resource.
**
** Copyright (C) 2003 ~ 2007 Feynman Software.
**
** Create date: 2003/08/14
*/

#ifndef GUI_INCORERES_H
    #define GUI_INCORERES_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */

/* Function definitions */

#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif  /* GUI_INCORERES_H */

