/*
** $Id: animation_impl.h 8810 2007-12-26 05:17:04Z xwyan $: 
**
** Copyright (C) 2004~2007 Feynman Software.
**
** Create date: 2004/7/14
*/


#ifndef __ANIMATION_IMPL_H_
#define __ANIMATION_IMPL_H_

#ifdef  __cplusplus
extern  "C" {
#endif

BOOL RegisterAnimationControl (void);
#ifdef  __cplusplus
}
#endif

#endif // __ANIMATION_IMPL_H_

