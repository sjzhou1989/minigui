/*
** $Id: ctrlmisc.h 8944 2007-12-29 08:29:16Z xwyan $
**
** ctrlmisc.c: the head file of Control Misc module.
**
** Copyright (c) 2003 ~ 2007 Feynman Software.
** Copyright (c) 1999 ~ 2002 Wei Yongming.
**
** Create date: 1999/8/24
*/

#ifndef  _CONTROL_MISC_H
#define  _CONTROL_MISC_h

#ifdef  __cplusplus
extern  "C" {
#endif

#ifdef  __cplusplus
}
#endif

#endif  /* _CONTROL_MISC_H */
 
